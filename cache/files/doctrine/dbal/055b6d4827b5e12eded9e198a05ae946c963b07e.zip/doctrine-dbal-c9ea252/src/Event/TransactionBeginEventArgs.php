<?php

declare(strict_types=1);

namespace Doctrine\DBAL\Event;

/** @deprecated */
class TransactionBeginEventArgs extends TransactionEventArgs
{
}
