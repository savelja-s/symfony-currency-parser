<?php

return [
    'Names' => [
        'TTD' => [
            '$',
            'Trinidad & Tobago Dollar',
        ],
    ],
];
