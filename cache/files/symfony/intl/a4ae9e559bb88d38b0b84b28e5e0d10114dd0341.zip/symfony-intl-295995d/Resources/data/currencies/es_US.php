<?php

return [
    'Names' => [
        'BDT' => [
            'BDT',
            'taka bangladesí',
        ],
        'BTN' => [
            'BTN',
            'ngultrum butanés',
        ],
        'ETB' => [
            'ETB',
            'birr',
        ],
        'JPY' => [
            '¥',
            'yen',
        ],
        'LAK' => [
            'LAK',
            'kip laosiano',
        ],
        'THB' => [
            'THB',
            'bat',
        ],
        'USD' => [
            '$',
            'dólar estadounidense',
        ],
        'UZS' => [
            'UZS',
            'sum',
        ],
        'VND' => [
            'VND',
            'dong vietnamita',
        ],
        'XAF' => [
            'XAF',
            'franco CFA de África central',
        ],
        'ZMW' => [
            'ZMW',
            'kwacha zambiano',
        ],
    ],
];
