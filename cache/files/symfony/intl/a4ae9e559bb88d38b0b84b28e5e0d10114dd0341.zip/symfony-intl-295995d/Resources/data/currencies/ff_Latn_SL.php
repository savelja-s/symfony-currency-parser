<?php

return [
    'Names' => [
        'SLE' => [
            'Le',
            'Lewoon Seraa Liyon',
        ],
    ],
];
