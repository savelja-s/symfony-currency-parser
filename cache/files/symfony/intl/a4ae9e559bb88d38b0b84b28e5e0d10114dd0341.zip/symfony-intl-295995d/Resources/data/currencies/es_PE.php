<?php

return [
    'Names' => [
        'PEN' => [
            'S/',
            'sol peruano',
        ],
    ],
];
