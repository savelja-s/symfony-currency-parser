<?php

return [
    'Names' => [
        'ANG' => [
            'ANG',
            'florín de las Antillas Neerlandesas',
        ],
        'BMD' => [
            'BMD',
            'dólar de Bermudas',
        ],
        'EUR' => [
            'EUR',
            'euro',
        ],
        'HTG' => [
            'HTG',
            'gourde haitiano',
        ],
        'KZT' => [
            'KZT',
            'tenge kazajo',
        ],
        'MWK' => [
            'MWK',
            'kwacha malauí',
        ],
        'NIO' => [
            'NIO',
            'córdoba nicaragüense',
        ],
        'THB' => [
            'THB',
            'baht tailandes',
        ],
        'USD' => [
            'USD',
            'dólar estadounidense',
        ],
        'UZS' => [
            'UZS',
            'som uzbeko',
        ],
        'VND' => [
            'VND',
            'dong',
        ],
    ],
];
